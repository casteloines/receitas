import json
from typing import List, Dict

class RecipeManager:
    def __init__(self):
        self.recipes = self._load_recipes()
        self.categories = self._load_categories()
        self.recipes_file_path = 'data/recipes.json'
        self.categories_file_path = 'data/categories.json'

    def _load_recipes(self) -> List[Dict]:
        """Carrega as receitas do arquivo JSON"""
        with open('data/recipes.json', 'r') as f:
            data = json.load(f)
            return data['recipes']

    def _load_categories(self) -> List[str]:
        """Carrega as categorias do arquivo JSON"""
        try:
            with open('data/categories.json', 'r') as f:
                data = json.load(f)
                return data['categories']
        except FileNotFoundError:
            # Categorias padrão se o arquivo não existir
            default_categories = [
                "Massas Base",
                "Pastelaria Fina",
                "Pastelaria Clássica",
                "Petit Déjeuner",
                "Chocolataria",
                "Sobremesas de Restaurante",
                "Buffet & Eventos",
                "Pastelaria de Vitrine",
                "Produtos de Vitrine",
                "Pastelaria Sazonal"
            ]
            self._save_categories(default_categories)
            return default_categories

    def _save_recipes(self) -> bool:
        """Salva as receitas no arquivo JSON"""
        try:
            with open(self.recipes_file_path, 'w') as f:
                json.dump({"recipes": self.recipes}, f, indent=2, ensure_ascii=False)
            return True
        except Exception as e:
            print(f"Erro ao salvar receitas: {e}")
            return False

    def _save_categories(self, categories: List[str]) -> bool:
        """Salva as categorias no arquivo JSON"""
        try:
            with open(self.categories_file_path, 'w') as f:
                json.dump({"categories": categories}, f, indent=2, ensure_ascii=False)
            self.categories = categories
            return True
        except Exception as e:
            print(f"Erro ao salvar categorias: {e}")
            return False

    def get_categories(self) -> List[str]:
        """Retorna todas as categorias"""
        return sorted(self.categories)

    def add_category(self, category: str) -> bool:
        """Adiciona uma nova categoria"""
        if category and category not in self.categories:
            self.categories.append(category)
            return self._save_categories(self.categories)
        return False

    def remove_category(self, category: str) -> bool:
        """Remove uma categoria se não houver receitas usando ela"""
        if category in self.categories:
            # Verifica se existem receitas usando esta categoria
            recipes_with_category = [r for r in self.recipes if r['category'] == category]
            if not recipes_with_category:
                self.categories.remove(category)
                return self._save_categories(self.categories)
        return False

    def update_category(self, old_category: str, new_category: str) -> bool:
        """Atualiza o nome de uma categoria e todas as receitas relacionadas"""
        if old_category in self.categories and new_category and old_category != new_category:
            # Atualiza o nome da categoria
            self.categories[self.categories.index(old_category)] = new_category

            # Atualiza todas as receitas com esta categoria
            for recipe in self.recipes:
                if recipe['category'] == old_category:
                    recipe['category'] = new_category

            # Salva as alterações
            return self._save_categories(self.categories) and self._save_recipes()
        return False

    def search_recipes(self, query: str = "", category: str = "Todas") -> List[Dict]:
        """
        Busca receitas com base em uma query e categoria

        Args:
            query (str): Termo de busca
            category (str): Categoria para filtrar

        Returns:
            List[Dict]: Lista de receitas filtradas
        """
        filtered_recipes = self.recipes

        # Filtro por categoria
        if category != "Todas":
            filtered_recipes = [
                recipe for recipe in filtered_recipes 
                if recipe['category'] == category
            ]

        # Filtro por termo de busca
        if query:
            query = query.lower()
            filtered_recipes = [
                recipe for recipe in filtered_recipes
                if query in recipe['name'].lower()
            ]

        return filtered_recipes

    def add_recipe(self, recipe: Dict) -> bool:
        """
        Adiciona uma nova receita à coleção

        Args:
            recipe (Dict): Nova receita a ser adicionada

        Returns:
            bool: True se a receita foi adicionada com sucesso
        """
        try:
            # Validação básica
            required_fields = [
                'name', 'category', 'prep_time', 'baking_time', 'difficulty',
                'servings', 'pan_size', 'temperature', 'ingredients', 'instructions'
            ]

            if not all(field in recipe for field in required_fields):
                return False

            # Verifica se a categoria existe
            if recipe['category'] not in self.categories:
                return False

            # Adiciona a receita à lista
            self.recipes.append(recipe)

            # Salva no arquivo
            return self._save_recipes()

        except Exception as e:
            print(f"Erro ao adicionar receita: {e}")
            return False