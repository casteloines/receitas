import streamlit as st
import json
from utils.recipe_manager import RecipeManager
from decimal import Decimal, ROUND_HALF_UP

# Configuração da página
st.set_page_config(
    page_title="Livro de Receitas - Pastelaria",
    page_icon="🧁",
    layout="wide"
)

# Carregando estilos CSS
with open('styles/styles.css') as f:
    st.markdown(f'<style>{f.read()}</style>', unsafe_allow_html=True)

# Inicializando o gerenciador de receitas
recipe_manager = RecipeManager()

# Cabeçalho
st.title("🧁 Livro de Receitas de Pastelaria")

# Tabs para navegação
tab1, tab2, tab3 = st.tabs(["📖 Ver Receitas", "➕ Adicionar Receita", "⚙️ Gerenciar Categorias"])

with tab1:
    st.markdown("### Descubra deliciosas receitas de doces e sobremesas")

    # Barra de busca e filtros
    col1, col2 = st.columns([2,1])
    with col1:
        search_query = st.text_input("🔍 Buscar receitas", "")
    with col2:
        categories = recipe_manager.get_categories()
        selected_category = st.selectbox("Categoria", ["Todas"] + categories)

    # Exibição das receitas
    recipes = recipe_manager.search_recipes(search_query, selected_category)

    # Grid de receitas
    cols = st.columns(3)
    for idx, recipe in enumerate(recipes):
        with cols[idx % 3]:
            st.markdown(f"""
            <div class="recipe-card">
                <img src="{recipe['image_url']}" alt="{recipe['name']}" class="recipe-image">
                <div class="recipe-content">
                    <h3>{recipe['name']}</h3>
                    <div class="recipe-stats">
                        <span class="stat-item">⏱️ {recipe['prep_time'] + recipe['baking_time']} min</span>
                        <span class="stat-item">🌡️ {recipe['temperature']}°C</span>
                        <span class="stat-item">👥 {recipe['servings']} porções</span>
                    </div>
                </div>
            </div>
            """, unsafe_allow_html=True)

            if st.button(f"Ver ficha técnica", key=f"recipe_{idx}"):
                st.session_state.selected_recipe = recipe

with tab2:
    st.markdown("### Adicionar Nova Receita")

    # Formulário para nova receita
    with st.form("nova_receita"):
        nome = st.text_input("Nome da Receita")
        categoria = st.selectbox("Categoria", recipe_manager.get_categories())

        col1, col2 = st.columns(2)
        with col1:
            tempo_preparo = st.number_input("Tempo de Preparo (min)", min_value=0)
            tempo_forno = st.number_input("Tempo no Forno (min)", min_value=0)
            temperatura = st.number_input("Temperatura (°C)", min_value=0)

        with col2:
            dificuldade = st.selectbox("Dificuldade", ["Fácil", "Médio", "Difícil"])
            porcoes = st.number_input("Porções", min_value=1)
            forma = st.text_input("Tamanho da Forma")

        # Ingredientes com preços
        st.markdown("### Ingredientes")
        ingredientes = []

        for i in range(10):  # Permite até 10 ingredientes
            col1, col2, col3, col4 = st.columns([1,1,2,1])
            with col1:
                quantidade = st.number_input(f"Quantidade {i+1}", key=f"qtd_{i}", min_value=0.0)
            with col2:
                unidade = st.selectbox(f"Unidade {i+1}", 
                    ["gramas", "ml", "unidades", "kg", "litros"], key=f"und_{i}")
            with col3:
                item = st.text_input(f"Ingrediente {i+1}", key=f"ing_{i}")
            with col4:
                preco = st.number_input(f"Preço/Kg {i+1}", key=f"price_{i}", min_value=0.0)

            if quantidade > 0 and item:
                ingredientes.append({
                    "amount": quantidade,
                    "unit": unidade,
                    "item": item,
                    "price_per_kg": preco
                })

        # Modo de Preparo
        st.markdown("### Modo de Preparo")
        instrucoes = []
        for i in range(10):  # Permite até 10 passos
            passo = st.text_area(f"Passo {i+1}", key=f"passo_{i}")
            if passo:
                instrucoes.append(passo)

        # Custos adicionais
        st.markdown("### Custos Adicionais")
        col1, col2 = st.columns(2)
        with col1:
            custo_energia = st.number_input("Custo de Energia (€)", min_value=0.0)
            custo_mao_obra = st.number_input("Custo de Mão de Obra (€)", min_value=0.0)
        with col2:
            margem_lucro = st.number_input("Margem de Lucro (%)", min_value=0.0, max_value=100.0, value=30.0)
            outros_custos = st.number_input("Outros Custos (€)", min_value=0.0)

        # URL da imagem
        image_url = st.text_input("URL da Imagem da Receita")

        # Botão para salvar
        submitted = st.form_submit_button("Salvar Receita")

        if submitted and nome and categoria and len(ingredientes) > 0 and len(instrucoes) > 0:
            nova_receita = {
                "name": nome,
                "category": categoria,
                "prep_time": tempo_preparo,
                "baking_time": tempo_forno,
                "difficulty": dificuldade,
                "servings": porcoes,
                "pan_size": forma,
                "temperature": temperatura,
                "image_url": image_url,
                "ingredients": ingredientes,
                "instructions": instrucoes,
                "additional_costs": {
                    "energy": custo_energia,
                    "labor": custo_mao_obra,
                    "other": outros_custos,
                    "profit_margin": margem_lucro
                }
            }

            if recipe_manager.add_recipe(nova_receita):
                st.success("Receita adicionada com sucesso!")
                st.experimental_rerun()
            else:
                st.error("Erro ao adicionar receita. Por favor, tente novamente.")

with tab3:
    st.markdown("### Gerenciar Categorias")

    # Adicionar nova categoria
    with st.form("nova_categoria"):
        nova_categoria = st.text_input("Nova Categoria")
        submitted = st.form_submit_button("Adicionar Categoria")

        if submitted and nova_categoria:
            if recipe_manager.add_category(nova_categoria):
                st.success(f"Categoria '{nova_categoria}' adicionada com sucesso!")
                st.experimental_rerun()
            else:
                st.error("Erro ao adicionar categoria. Verifique se ela já existe.")

    # Lista de categorias existentes
    st.markdown("### Categorias Existentes")
    for categoria in recipe_manager.get_categories():
        col1, col2, col3 = st.columns([3, 1, 1])

        with col1:
            st.write(categoria)

        with col2:
            if st.button(f"Editar {categoria}", key=f"edit_{categoria}"):
                st.session_state.categoria_para_editar = categoria

        with col3:
            if st.button(f"Remover {categoria}", key=f"remove_{categoria}"):
                if recipe_manager.remove_category(categoria):
                    st.success(f"Categoria '{categoria}' removida com sucesso!")
                    st.experimental_rerun()
                else:
                    st.error("Não é possível remover esta categoria pois existem receitas associadas a ela.")

    # Form para editar categoria
    if 'categoria_para_editar' in st.session_state:
        st.markdown("### Editar Categoria")
        with st.form("editar_categoria"):
            novo_nome = st.text_input("Novo nome da categoria", st.session_state.categoria_para_editar)
            submitted = st.form_submit_button("Salvar Alterações")

            if submitted and novo_nome:
                if recipe_manager.update_category(st.session_state.categoria_para_editar, novo_nome):
                    st.success(f"Categoria atualizada com sucesso!")
                    del st.session_state.categoria_para_editar
                    st.experimental_rerun()
                else:
                    st.error("Erro ao atualizar categoria.")


# Exibição da ficha técnica
if 'selected_recipe' in st.session_state:
    recipe = st.session_state.selected_recipe

    st.markdown("---")

    # Cabeçalho da ficha técnica
    st.markdown(f"""
    <div class="tech-sheet">
        <h2>{recipe['name']}</h2>
        
        <div class="recipe-info">
            <div class="info-header">
                <div class="info-row">
                    <div class="info-item">
                        <i class="fas fa-clock"></i>
                        <strong>Tempo de Confeção:</strong>
                        <span>{recipe['prep_time'] + recipe['baking_time']} min</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-users"></i>
                        <strong>Número de Doses:</strong>
                        <span>{recipe['servings']} porções</span>
                    </div>
                </div>
                <div class="info-row">
                    <div class="info-item">
                        <i class="fas fa-utensils"></i>
                        <strong>Forma:</strong>
                        <span>{recipe['pan_size']}</span>
                    </div>
                    <div class="info-item">
                        <i class="fas fa-temperature-high"></i>
                        <strong>Temperatura:</strong>
                        <span>{recipe['temperature']}°C</span>
                    </div>
                </div>
            </div>
        </div>

        <div class="tech-sheet-section">
            <h3>Ingredientes</h3>
            <div class="ingredients-checklist">
    """, unsafe_allow_html=True)

    for ing in recipe['ingredients']:
        st.markdown(f"""
            <label class="ingredient-item">
                <input type="checkbox">
                <span class="ingredient-text">
                    <span class="amount">{ing['amount']}</span>
                    <span class="unit">{ing['unit'].replace('gramas', 'gr').replace('unidades', 'uni')}</span>
                    <span class="item">{ing['item']}</span>
                </span>
            </label>
        """, unsafe_allow_html=True)

    st.markdown("""
            </div>
        </div>

        <div class="tech-sheet-section">
            <h3>Modo de Preparo</h3>
            <div class="instructions-list">
    """, unsafe_allow_html=True)

    for idx, step in enumerate(recipe['instructions'], 1):
        st.markdown(f"""
            <div class="instruction-step">
                <span class="step-number">{idx}.</span> {step}
            </div>
        """, unsafe_allow_html=True)

    st.markdown("</div></div></div>", unsafe_allow_html=True)

    # Botão para voltar
    if st.button("Voltar para lista de receitas"):
        del st.session_state.selected_recipe
        st.experimental_rerun()